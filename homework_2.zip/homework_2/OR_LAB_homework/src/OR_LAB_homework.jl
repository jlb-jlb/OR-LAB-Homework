module OR_LAB_homework

greet() = print("Hello World!")

end # module
